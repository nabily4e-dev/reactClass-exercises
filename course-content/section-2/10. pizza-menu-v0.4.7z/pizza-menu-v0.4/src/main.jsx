// Imports necessary for building React components and rendering them to the DOM
import React from 'react';
import ReactDOM from 'react-dom/client';

//include the css styles file
import './main.css';

// Add project assets
// pizzas images, index.css, and data.js

// Pizza Project components. Pizza, Header, Menu, Footer
function Pizza() {
  return (
    <div>
      <img src='images\pizzas\prosciutto.jpg' />
      <h3>Pizza Prosciutto</h3>
      <p>Tomato, mozarella, ham, aragula, and burrata cheese</p>
    </div>
  );
}

function Header() {
  // const styles = { color: 'red', fontSize: '36px', transform: 'uppercase' };

  return (
    // inline styling, you can extract into a variable
    <header className='header'>
      <h1>Fast React Pizza Co.</h1>
    </header>
  );
}

function Menu() {
  return (
    //! <div class='container'>
    <main className='menu'>
      <h2>Our menu</h2>
      <Pizza />
      <Pizza />
      <Pizza />
      <Pizza />
    </main>
  );
}

function Footer() {
  // Using JavaScript logic in React
  const hour = new Date().getHours();
  const openHour = 12; // change the value to switch the result of the isOpen variable
  const closHour = 22;
  const isOpen = hour >= openHour && hour <= closHour;
  console.log(isOpen);

  //? We can move the condition inside a variable for effeminacy
  // if (hour >= openHour && hour <= closHour) alert("We're currently open!");
  // else alert("Sorry, we're closed");

  return (
    <footer className='footer'>
      {new Date().toLocaleTimeString()}. We&apos;re currently open!
    </footer>
  );
}

// React main (root) functional component
function App() {
  return (
    <div className='container'>
      <Header />
      <Menu />
      <Footer />
    </div>
  );
}

// React 18
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// React 17 older
// ReactDOM.render(<App/>, document.getElementById('root'))
